# Clone of kindmeal.com
kindmeal.com website was our project for Unit-2 Construct week at Masai School.
We have made this project in 5 days.<br />
***Our clone website - (https://keen-pasca-121c61.netlify.app/index.htm)***


# Tech Stack
-HTML
-CSS
-JAVA SCRIPT
-GIT HUB

## Features

-Login and signin page
-Carouse for home page
-Filters of Custom price
-Sorting for price and search bar
-Manual and automatic slider for home page
-Add to cart opt for adding items
-Increment and Decrement Number of person according to that price is also changes
-Discount price after applying coupon

# Challenges we face during Construct week

1. On the first day we did't know about each other what is our weakness and what is our strong areas. So it was very difficult to assign right thing to right person.

2. Everyone's mind works differently and so ours. The website given to us was a website of get free coupons. We changed some things in website. Everyone's idea was different. It is very difficult to choose one idea.

3. In our website the cart page was not there so we have create oneghg from scratch. It was very hard to decide which layout should we perfect for cart page.

4. Another problem was to merge all of the files in a proper sequence which was again a difficult task for us because while merging and connecting all the pages some of the pages had the same name, and while running the site it was redirecting to some other pages so it was difficult to find the location and to rename the file.

5. We faced challenges with CSS tags and class also, because when we merged CSS files for any page in which 2-3 members have worked, sometimes tags were colliding because of the same names of tags and classes.


## Team

-Aman Sharma
-Sandeep Sharma
-Gaurav Mishra
-Vijay yadav
-Saurabh Kumar


## Authors

- [@Aman Sharma](https://github.com/Aman103767)
